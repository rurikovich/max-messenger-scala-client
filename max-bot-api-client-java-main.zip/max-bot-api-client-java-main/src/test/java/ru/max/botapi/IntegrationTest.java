package ru.max.botapi;


public interface IntegrationTest {
}
