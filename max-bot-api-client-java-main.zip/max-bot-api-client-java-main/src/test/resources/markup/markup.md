***strong emph***

***strong** in emph*

***emph* in strong**

`` foo ` bar``

``
foo
``

The `String` class represents character strings.
All string literals in Kotlin programs, such as `"abc"`, are
implemented as instances of this class.

```baz\```

[link](/uri "title")

[link](/uri)

[link]()

[link]((foo)and(bar))

@mention

@mention at text start

mention at end @mention

mention @mention text

**@mention** strong

strong ***@mention*** and emphasized

this is email@max.ru, not mention

mention in code span `@mention` should be ignored

```
@mention in code should be ignored also
```

mention by user id [some-user](max://user/1234567)

this ^^text^^ is highlighted