package ru.max.botapi.exceptions;

public class AccessForbiddenException extends APIException {
    public AccessForbiddenException(String message) {
        super(message);
    }
}
